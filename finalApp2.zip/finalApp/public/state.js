export const API = '/api';

let currentUser = null;
let selectedContact = null;
let convoyList = [];
let messagePoll = null;

export function getCurrentUser() {
  return currentUser;
}

export function setCurrentUser(user) {
  currentUser = user;
}


export function getSelectedContact() {
  return selectedContact;
}

export function setSelectedContact(contact) {
  selectedContact = contact;
}


export function getConvoyList() {
  return convoyList;
}

export function setConvoyList(list) {
  convoyList = list;
}


export function getMessagePoll() {
  return messagePoll;
}

export function setMessagePoll(poll) {
  messagePoll = poll;
}
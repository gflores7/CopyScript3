const API = '/api';

let currentUser = null;
let selectedContact = null;
let convoys = [];
let messagePoll = null;

const registerForm = document.getElementById('registerForm');
const loginForm = document.getElementById('loginForm');
const createConvoyForm = document.getElementById('createConvoyForm');
const joinConvoyForm = document.getElementById('joinConvoyForm');
const friendRequestForm = document.getElementById('friendRequestForm');
const messageForm = document.getElementById('messageForm');

const registerResult = document.getElementById('registerResult');
const loginResult = document.getElementById('loginResult');
const convoyResult = document.getElementById('convoyResult');
const friendResult = document.getElementById('friendResult');
const gpsResult = document.getElementById('gpsResult');
const currentUserEl = document.getElementById('currentUser');
const activeConvoySelect = document.getElementById('activeConvoySelect');
const membersList = document.getElementById('membersList');
const gpsList = document.getElementById('gpsList');
const friendsList = document.getElementById('friendsList');
const requestsList = document.getElementById('requestsList');
const contactsList = document.getElementById('contactsList');
const chatTitle = document.getElementById('chatTitle');
const messagesBox = document.getElementById('messagesBox');

registerForm.addEventListener('submit', registerUser);
loginForm.addEventListener('submit', loginUser);
createConvoyForm.addEventListener('submit', createConvoy);
joinConvoyForm.addEventListener('submit', joinConvoy);
friendRequestForm.addEventListener('submit', sendFriendRequest);
messageForm.addEventListener('submit', sendMessage);

document.getElementById('logoutBtn').addEventListener('click', logout);
document.getElementById('refreshBtn').addEventListener('click', refreshAll);
document.getElementById('loadMembersBtn').addEventListener('click', loadMembers);
document.getElementById('loadGpsBtn').addEventListener('click', loadGps);
document.getElementById('showFriendsBtn').addEventListener('click', loadFriends);
document.getElementById('showRequestsBtn').addEventListener('click', loadRequests);
document.getElementById('shareLocationBtn').addEventListener('click', shareLocation);

restoreUser();

function setText(el, text, isError = false) {
  el.textContent = text;
  el.classList.toggle('error', isError);
}

function requireLogin() {
  if (!currentUser) {
    setText(loginResult, 'Please log in first.', true);
    return false;
  }
  return true;
}

function getActiveConvoyID() {
  const value = activeConvoySelect.value;
  return value ? Number(value) : null;
}

async function api(path, options = {}) {
  const res = await fetch(`${API}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });

  const contentType = res.headers.get('content-type') || '';
  const data = contentType.includes('application/json') ? await res.json() : await res.text();

  if (!res.ok) {
    throw new Error(data.message || data || 'Request failed');
  }

  return data;
}

async function registerUser(event) {
  event.preventDefault();

  try {
    const data = await api('/register', {
      method: 'POST',
      body: JSON.stringify({
        userName: document.getElementById('regUserName').value.trim(),
        first_name: document.getElementById('regFirstName').value.trim(),
        last_name: document.getElementById('regLastName').value.trim(),
        email: document.getElementById('regEmail').value.trim(),
        password: document.getElementById('regPassword').value
      })
    });

    setText(registerResult, `${data.message} User ID: ${data.userID}`);
    registerForm.reset();
  } catch (error) {
    setText(registerResult, error.message, true);
  }
}

async function loginUser(event) {
  event.preventDefault();

  try {
    const data = await api('/login', {
      method: 'POST',
      body: JSON.stringify({
        userName: document.getElementById('loginUserName').value.trim(),
        password: document.getElementById('loginPassword').value
      })
    });

    currentUser = data.user;
    localStorage.setItem('convoyUser', JSON.stringify(currentUser));
    renderCurrentUser();
    setText(loginResult, data.message);
    await refreshAll();
  } catch (error) {
    setText(loginResult, error.message, true);
  }
}

function logout() {
  currentUser = null;
  selectedContact = null;
  convoys = [];
  localStorage.removeItem('convoyUser');
  if (messagePoll) clearInterval(messagePoll);
  renderCurrentUser();
  activeConvoySelect.innerHTML = '';
  contactsList.innerHTML = '';
  membersList.innerHTML = '';
  gpsList.innerHTML = '';
  friendsList.innerHTML = '';
  requestsList.innerHTML = '';
  messagesBox.innerHTML = '';
  chatTitle.textContent = 'Select someone to chat';
  setText(loginResult, 'Logged out.');
}

function restoreUser() {
  const saved = localStorage.getItem('convoyUser');
  if (!saved) {
    renderCurrentUser();
    return;
  }

  try {
    currentUser = JSON.parse(saved);
    renderCurrentUser();
    refreshAll();
  } catch {
    localStorage.removeItem('convoyUser');
  }
}

function renderCurrentUser() {
  currentUserEl.textContent = currentUser
    ? `Logged in as ${currentUser.first_name} ${currentUser.last_name} (@${currentUser.userName})`
    : 'Not logged in.';
}

async function refreshAll() {
  if (!requireLogin()) return;
  await Promise.all([loadConvoys(), loadContacts(), loadFriends(), loadRequests()]);
}











// MOMEN

async function loadConvoys() {
  if (!currentUser) return;

  try {
    convoys = await api(`/convoys/by-user/${currentUser.userID}`);
    activeConvoySelect.innerHTML = '';

    if (convoys.length === 0) {
      const option = document.createElement('option');
      option.value = '';
      option.textContent = 'No convoys yet';
      activeConvoySelect.appendChild(option);
      membersList.innerHTML = '';
      gpsList.innerHTML = '';
      return;
    }

    convoys.forEach((convoy) => {
      const option = document.createElement('option');
      option.value = convoy.convoyID;
      option.textContent = `${convoy.name} (${convoy.joinCode})`;
      activeConvoySelect.appendChild(option);
    });

    await loadMembers();
    await loadGps();
  } catch (error) {
    setText(convoyResult, error.message, true);
  }
}

async function createConvoy(event) {
  event.preventDefault();
  if (!requireLogin()) return;

  try {
    const data = await api('/convoys', {
      method: 'POST',
      body: JSON.stringify({
        userID: currentUser.userID,
        name: document.getElementById('convoyName').value.trim(),
        joinCode: document.getElementById('createJoinCode').value.trim()
      })
    });

    setText(convoyResult, `${data.message} Convoy ID: ${data.convoyID}`);
    createConvoyForm.reset();
    await loadConvoys();
  } catch (error) {
    setText(convoyResult, error.message, true);
  }
}

async function joinConvoy(event) {
  event.preventDefault();
  if (!requireLogin()) return;

  try {
    const data = await api('/convoys/join', {
      method: 'POST',
      body: JSON.stringify({
        userID: currentUser.userID,
        joinCode: document.getElementById('joinCode').value.trim()
      })
    });

    setText(convoyResult, `${data.message} Convoy ID: ${data.convoyID}`);
    joinConvoyForm.reset();
    await loadConvoys();
  } catch (error) {
    setText(convoyResult, error.message, true);
  }
}

async function loadMembers() {
  const convoyID = getActiveConvoyID();
  if (!convoyID) {
    membersList.innerHTML = '<p>No active convoy selected.</p>';
    return;
  }

  try {
    const members = await api(`/convoys/${convoyID}/members`);
    membersList.innerHTML = members.length
      ? members.map((member) => `<div>${member.userName} - ${member.role}</div>`).join('')
      : '<p>No members found.</p>';
  } catch (error) {
    membersList.innerHTML = `<p class="error">${error.message}</p>`;
  }
}






// MARCOS



async function sendFriendRequest(event) {
  event.preventDefault();
  if (!requireLogin()) return;

  try {
    const data = await api('/friends/request', {
      method: 'POST',
      body: JSON.stringify({
        currentUserID: currentUser.userID,
        friendUsername: document.getElementById('friendUsername').value.trim()
      })
    });

    setText(friendResult, data.message);
    friendRequestForm.reset();
    await loadRequests();
  } catch (error) {
    setText(friendResult, error.message, true);
  }
}

async function loadFriends() {
  if (!currentUser) return;

  try {
    const friends = await api(`/friends/list/${currentUser.userID}`);
    friendsList.innerHTML = friends.length
      ? friends.map((friend) => `<div>${friend.userName}</div>`).join('')
      : '<p>No friends yet.</p>';
  } catch (error) {
    friendsList.innerHTML = `<p class="error">${error.message}</p>`;
  }
}

async function loadRequests() {
  if (!currentUser) return;

  try {
    const requests = await api(`/friends/requests/${currentUser.userID}`);

    if (requests.length === 0) {
      requestsList.innerHTML = '<p>No pending requests.</p>';
      return;
    }

    requestsList.innerHTML = '';
    requests.forEach((request) => {
      const row = document.createElement('div');
      row.className = 'request-row';
      row.innerHTML = `
        <span>${request.senderName}</span>
        <div class="row gap">
          <button type="button" data-id="${request.sender_id}" data-accept="true">Accept</button>
          <button type="button" data-id="${request.sender_id}" data-accept="false">Deny</button>
        </div>
      `;
      requestsList.appendChild(row);
    });

    requestsList.querySelectorAll('button').forEach((button) => {
      button.addEventListener('click', async () => {
        await respondToRequest(Number(button.dataset.id), button.dataset.accept === 'true');
      });
    });
  } catch (error) {
    requestsList.innerHTML = `<p class="error">${error.message}</p>`;
  }
}

async function respondToRequest(senderID, accept) {
  try {
    const data = await api('/friends/respond', {
      method: 'POST',
      body: JSON.stringify({
        sender_id: senderID,
        receiver_id: currentUser.userID,
        accept
      })
    });

    setText(friendResult, data.message);
    await loadFriends();
    await loadRequests();
  } catch (error) {
    setText(friendResult, error.message, true);
  }
}

async function loadContacts() {
  if (!currentUser) return;

  try {
    const contacts = await api(`/users/${currentUser.userID}/contacts`);
    contactsList.innerHTML = '';

    if (contacts.length === 0) {
      contactsList.innerHTML = '<p>No contacts available.</p>';
      return;
    }

    contacts.forEach((contact) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'contact-btn';
      button.textContent = `${contact.first_name} ${contact.last_name} (@${contact.userName})`;
      button.addEventListener('click', () => selectContact(contact));
      contactsList.appendChild(button);
    });
  } catch (error) {
    contactsList.innerHTML = `<p class="error">${error.message}</p>`;
  }
}









// GILBERTO

async function selectContact(contact) {
  selectedContact = contact;
  chatTitle.textContent = `Chat with ${contact.first_name} ${contact.last_name}`;
  await loadMessages();

  if (messagePoll) clearInterval(messagePoll);
  messagePoll = setInterval(loadMessages, 3000);
}

async function loadMessages() {
  if (!currentUser || !selectedContact) return;

  try {
    const messages = await api(`/messages/${currentUser.userID}/${selectedContact.userID}`);
    messagesBox.innerHTML = messages.length
      ? messages.map((message) => {
          const who = Number(message.sender_id) === Number(currentUser.userID) ? 'You' : selectedContact.first_name;
          return `<div class="message ${who === 'You' ? 'mine' : ''}"><strong>${who}:</strong> ${escapeHtml(message.message_text)}</div>`;
        }).join('')
      : '<p>No messages yet.</p>';
    messagesBox.scrollTop = messagesBox.scrollHeight;
  } catch (error) {
    messagesBox.innerHTML = `<p class="error">${error.message}</p>`;
  }
}

async function sendMessage(event) {
  event.preventDefault();
  if (!requireLogin()) return;
  if (!selectedContact) {
    alert('Select someone to message first.');
    return;
  }

  const input = document.getElementById('messageInput');
  const messageText = input.value.trim();
  if (!messageText) return;

  try {
    await api('/messages', {
      method: 'POST',
      body: JSON.stringify({
        sender_id: currentUser.userID,
        receiver_id: selectedContact.userID,
        message_text: messageText
      })
    });

    input.value = '';
    await loadMessages();
  } catch (error) {
    alert(error.message);
  }
}










//JOVANNY

async function shareLocation() {
  if (!requireLogin()) return;
  const convoyID = getActiveConvoyID();

  if (!convoyID) {
    setText(gpsResult, 'Select a convoy first.', true);
    return;
  }

  if (!navigator.geolocation) {
    setText(gpsResult, 'Geolocation is not supported by this browser.', true);
    return;
  }

  navigator.geolocation.getCurrentPosition(async (position) => {
    try {
      const latitude = Number(position.coords.latitude.toFixed(6));
      const longitude = Number(position.coords.longitude.toFixed(6));

      await api('/gps', {
        method: 'POST',
        body: JSON.stringify({ userID: currentUser.userID, convoyID, latitude, longitude })
      });

      setText(gpsResult, 'Location shared successfully.');
      await loadGps();
    } catch (error) {
      setText(gpsResult, error.message, true);
    }
  }, (error) => {
    setText(gpsResult, error.message || 'Could not get location.', true);
  });
}

async function loadGps() {
  const convoyID = getActiveConvoyID();
  if (!convoyID) {
    gpsList.innerHTML = '<p>No active convoy selected.</p>';
    return;
  }

  try {
    const locations = await api(`/gps/${convoyID}`);
    gpsList.innerHTML = locations.length
      ? locations.map((row) => `
          <div>
            <strong>${row.userName}</strong><br>
            <a href="https://www.google.com/maps?q=${row.latitude},${row.longitude}" target="_blank" rel="noreferrer">
              ${row.latitude}, ${row.longitude}
            </a>
          </div>
        `).join('')
      : '<p>No GPS data yet.</p>';
  } catch (error) {
    gpsList.innerHTML = `<p class="error">${error.message}</p>`;
  }
}










function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

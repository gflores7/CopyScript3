const express = require('express');
const mysql = require('mysql2');
const crypto = require('crypto');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const db = mysql.createPool({
  host: '127.0.0.1',
  user: 'root',
  password: 'test123!',
  database: 'finalDB',
  port: 3306,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
}).promise();

function hashPassword(password) {
  return crypto.createHash('sha256').update(password).digest('hex');
}

function makeId() {
  return crypto.randomUUID();
}

async function getUserByUsername(userName) {
  const [rows] = await db.query(
    'SELECT userID, userName, first_name, last_name, email FROM users WHERE userName = ?',
    [userName]
  );
  return rows[0] || null;
}

app.get('/api/health', async (req, res) => {
  try {
    await db.query('SELECT 1');
    res.json({ ok: true });
  } catch (error) {
    res.status(500).json({ ok: false, error: error.message });
  }
});

app.post('/api/register', async (req, res) => {
  try {
    const { userName, first_name, last_name, email, password } = req.body;

    if (!userName || !first_name || !last_name || !email || !password) {
      return res.status(400).json({ message: 'All fields are required.' });
    }

    const [result] = await db.query(
      `INSERT INTO users (userName, first_name, last_name, email, password)
       VALUES (?, ?, ?, ?, ?)`,
      [userName.trim(), first_name.trim(), last_name.trim(), email.trim(), hashPassword(password)]
    );

    res.json({ message: 'User created successfully.', userID: result.insertId });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({ message: 'Username or email already exists.' });
    }
    res.status(500).json({ message: 'Could not create user.' });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { userName, password } = req.body;
    if (!userName || !password) {
      return res.status(400).json({ message: 'Username and password are required.' });
    }

    const [rows] = await db.query(
      `SELECT userID, userName, first_name, last_name, email
       FROM users
       WHERE userName = ? AND password = ?`,
      [userName.trim(), hashPassword(password)]
    );

    if (rows.length === 0) {
      return res.status(401).json({ message: 'Invalid username or password.' });
    }

    res.json({ message: 'Login successful.', user: rows[0] });
  } catch (error) {
    res.status(500).json({ message: 'Login failed.' });
  }
});

app.post('/api/convoys', async (req, res) => {
  const connection = await db.getConnection();
  try {
    const { userID, name, joinCode } = req.body;
    if (!userID || !name || !joinCode) {
      return res.status(400).json({ message: 'Missing convoy data.' });
    }

    await connection.beginTransaction();

    const [result] = await connection.query(
      'INSERT INTO convoys (joinCode, host_userID, name) VALUES (?, ?, ?)',
      [joinCode.trim(), userID, name.trim()]
    );

    await connection.query(
      `INSERT INTO convoy_members (userID, convoyID, role)
       VALUES (?, ?, 'host')`,
      [userID, result.insertId]
    );

    await connection.commit();
    res.json({ message: 'Convoy created successfully.', convoyID: result.insertId });
  } catch (error) {
    await connection.rollback();
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({ message: 'Join code already exists or user is already in convoy.' });
    }
    res.status(500).json({ message: 'Could not create convoy.' });
  } finally {
    connection.release();
  }
});

app.post('/api/convoys/join', async (req, res) => {
  try {
    const { userID, joinCode } = req.body;
    if (!userID || !joinCode) {
      return res.status(400).json({ message: 'Missing join data.' });
    }

    const [convoys] = await db.query('SELECT convoyID FROM convoys WHERE joinCode = ?', [joinCode.trim()]);
    if (convoys.length === 0) {
      return res.status(404).json({ message: 'Convoy not found.' });
    }

    await db.query(
      `INSERT INTO convoy_members (userID, convoyID, role)
       VALUES (?, ?, 'member')`,
      [userID, convoys[0].convoyID]
    );

    res.json({ message: 'Joined convoy successfully.', convoyID: convoys[0].convoyID });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({ message: 'User is already in this convoy.' });
    }
    res.status(500).json({ message: 'Could not join convoy.' });
  }
});

app.get('/api/convoys/:convoyID/members', async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT u.userID, u.userName, cm.role
       FROM convoy_members cm
       JOIN users u ON u.userID = cm.userID
       WHERE cm.convoyID = ?
       ORDER BY FIELD(cm.role, 'host', 'member'), u.userName`,
      [req.params.convoyID]
    );

    res.json(rows);
  } catch (error) {
    res.status(500).json({ message: 'Could not load members.' });
  }
});

app.get('/api/convoys/by-user/:userID', async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT c.convoyID, c.name, c.joinCode, cm.role
       FROM convoy_members cm
       JOIN convoys c ON c.convoyID = cm.convoyID
       WHERE cm.userID = ?
       ORDER BY c.created_at DESC`,
      [req.params.userID]
    );
    res.json(rows);
  } catch (error) {
    res.status(500).json({ message: 'Could not load convoys.' });
  }
});

app.post('/api/friends/request', async (req, res) => {
  try {
    const { currentUserID, friendUsername } = req.body;
    if (!currentUserID || !friendUsername) {
      return res.status(400).json({ message: 'Missing friend data.' });
    }

    const friend = await getUserByUsername(friendUsername.trim());
    if (!friend) {
      return res.status(404).json({ message: 'User not found.' });
    }

    if (Number(currentUserID) === Number(friend.userID)) {
      return res.status(400).json({ message: 'You cannot add yourself.' });
    }

    const [existing] = await db.query(
      `SELECT * FROM friendships
       WHERE (sender_id = ? AND receiver_id = ?)
          OR (sender_id = ? AND receiver_id = ?)`,
      [currentUserID, friend.userID, friend.userID, currentUserID]
    );

    if (existing.length > 0) {
      const row = existing[0];
      if (row.status === 'accepted') {
        return res.status(400).json({ message: 'You are already friends.' });
      }
      if (row.status === 'pending') {
        return res.status(400).json({ message: 'A friend request already exists.' });
      }
      await db.query(
        'UPDATE friendships SET sender_id = ?, receiver_id = ?, status = ? WHERE id = ?',
        [currentUserID, friend.userID, 'pending', row.id]
      );
      return res.json({ message: 'Friend request re-sent.' });
    }

    await db.query(
      `INSERT INTO friendships (id, sender_id, receiver_id, status)
       VALUES (?, ?, ?, 'pending')`,
      [makeId(), currentUserID, friend.userID]
    );

    res.json({ message: 'Friend request sent.' });
  } catch (error) {
    res.status(500).json({ message: 'Could not send friend request.' });
  }
});

app.get('/api/friends/requests/:userID', async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT f.sender_id, u.userName AS senderName
       FROM friendships f
       JOIN users u ON u.userID = f.sender_id
       WHERE f.receiver_id = ? AND f.status = 'pending'
       ORDER BY f.created_at DESC`,
      [req.params.userID]
    );
    res.json(rows);
  } catch (error) {
    res.status(500).json({ message: 'Could not load friend requests.' });
  }
});

app.post('/api/friends/respond', async (req, res) => {
  try {
    const { sender_id, receiver_id, accept } = req.body;
    const newStatus = accept ? 'accepted' : 'rejected';

    const [result] = await db.query(
      `UPDATE friendships
       SET status = ?
       WHERE sender_id = ? AND receiver_id = ? AND status = 'pending'`,
      [newStatus, sender_id, receiver_id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Request not found.' });
    }

    res.json({ message: accept ? 'Friend request accepted.' : 'Friend request denied.' });
  } catch (error) {
    res.status(500).json({ message: 'Could not update friend request.' });
  }
});

app.get('/api/friends/list/:userID', async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT u.userID, u.userName
       FROM friendships f
       JOIN users u ON (
         (u.userID = f.sender_id AND f.receiver_id = ?)
         OR (u.userID = f.receiver_id AND f.sender_id = ?)
       )
       WHERE f.status = 'accepted'
       ORDER BY u.userName`,
      [req.params.userID, req.params.userID]
    );
    res.json(rows);
  } catch (error) {
    res.status(500).json({ message: 'Could not load friends.' });
  }
});

app.get('/api/users/:userID/contacts', async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT DISTINCT u.userID, u.userName, u.first_name, u.last_name
       FROM users u
       WHERE u.userID != ?
       ORDER BY u.userName`,
      [req.params.userID]
    );
    res.json(rows);
  } catch (error) {
    res.status(500).json({ message: 'Could not load users.' });
  }
});

app.post('/api/messages', async (req, res) => {
  try {
    const { sender_id, receiver_id, message_text } = req.body;
    if (!sender_id || !receiver_id || !message_text) {
      return res.status(400).json({ message: 'Missing message data.' });
    }

    await db.query(
      'INSERT INTO messages (sender_id, receiver_id, message_text) VALUES (?, ?, ?)',
      [sender_id, receiver_id, message_text.trim()]
    );

    res.json({ message: 'Message sent.' });
  } catch (error) {
    res.status(500).json({ message: 'Could not send message.' });
  }
});

app.get('/api/messages/:user1/:user2', async (req, res) => {
  try {
    const { user1, user2 } = req.params;
    const [rows] = await db.query(
      `SELECT id, sender_id, receiver_id, message_text, created_at
       FROM messages
       WHERE (sender_id = ? AND receiver_id = ?)
          OR (sender_id = ? AND receiver_id = ?)
       ORDER BY created_at ASC, id ASC`,
      [user1, user2, user2, user1]
    );
    res.json(rows);
  } catch (error) {
    res.status(500).json({ message: 'Could not load messages.' });
  }
});

app.post('/api/gps', async (req, res) => {
  try {
    const { userID, convoyID, latitude, longitude } = req.body;
    if (!userID || !convoyID || latitude === undefined || longitude === undefined) {
      return res.status(400).json({ message: 'Missing GPS data.' });
    }

    await db.query(
      `INSERT INTO gps (userID, convoyID, latitude, longitude)
       VALUES (?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE latitude = VALUES(latitude), longitude = VALUES(longitude)`,
      [userID, convoyID, latitude, longitude]
    );

    res.json({ message: 'Location shared successfully.' });
  } catch (error) {
    res.status(500).json({ message: 'Could not save location.' });
  }
});

app.get('/api/gps/:convoyID', async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT g.userID, u.userName, g.latitude, g.longitude, g.updatedAt
       FROM gps g
       JOIN users u ON u.userID = g.userID
       WHERE g.convoyID = ?
       ORDER BY g.updatedAt DESC`,
      [req.params.convoyID]
    );
    res.json(rows);
  } catch (error) {
    res.status(500).json({ message: 'Could not load GPS data.' });
  }
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Convoy app running at http://localhost:${PORT}`);
});
